package edu.umkc.moulika.myextensions;

import edu.umkc.moulika.myplugin.IGreeter;

public class GreeterIndia implements IGreeter {

	public GreeterIndia() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "Namaste in India";
	}

}
