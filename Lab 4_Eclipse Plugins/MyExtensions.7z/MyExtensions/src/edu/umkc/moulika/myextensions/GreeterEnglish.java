package edu.umkc.moulika.myextensions;

import edu.umkc.moulika.myplugin.IGreeter;

public class GreeterEnglish implements IGreeter {

	public GreeterEnglish() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "Hello in English";
	}

}
