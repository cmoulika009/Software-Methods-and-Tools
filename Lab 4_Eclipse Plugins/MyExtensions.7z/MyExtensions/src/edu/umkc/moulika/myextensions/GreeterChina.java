package edu.umkc.moulika.myextensions;

import edu.umkc.moulika.myplugin.IGreeter;

public class GreeterChina implements IGreeter {

	public GreeterChina() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "Ni Hao in Chinese";
	}
}
