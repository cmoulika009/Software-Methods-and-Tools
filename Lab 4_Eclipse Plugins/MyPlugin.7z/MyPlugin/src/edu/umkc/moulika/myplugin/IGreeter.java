package edu.umkc.moulika.myplugin;

public interface IGreeter {
	String sayHello();

}
